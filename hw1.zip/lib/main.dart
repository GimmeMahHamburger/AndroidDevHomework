import 'package:flutter/material.dart';

void main() {
  runApp(WorkoutHistoryPage());
}

enum Unit {seconds, repetitions, meters}

class Exercise {
  String name;
  int target;
  Unit measure;
  Exercise(this.name, this.target, this.measure);
}

class Result {
  Exercise exercise;
  double percent;
  Result(this.exercise, this.percent);
}

class Workout {
  String date;
  List<Result> collection;
  Workout(this.date, this.collection);
}

Workout tempData=Workout(
  'today',
  [
    Result(
      Exercise(
        "Squats",
        40,
        Unit.repetitions
      ),
      0.6
    ),
    Result(
      Exercise(
        "Flips",
        3,
        Unit.meters
      ),
      1.0
    )
  ]
);

class WorkoutHistoryPage extends StatelessWidget {
  const WorkoutHistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      home: WorkoutDetails(workout: tempData),
    );
  }
}

class WorkoutDetails extends StatelessWidget {
  final Workout workout;
  const WorkoutDetails({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children:[
            Text("${workout.collection.length} results in this workout"),
            Text("Done on ${workout.date}"),
            Column(
              children: workout.collection.map(
                      (work) => ResultDetails(result: work,) //taken from your git repo at
              ).toList(),                                   //lib/product_review_list.dart it was mighty helpful for iterating
            )
          ]
        )
      )
    );
  }
}

class ResultDetails extends StatelessWidget {
  final Result result;
  const ResultDetails({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    return Column(
      children:[
        Text("Exercise name: ${result.exercise.name}"),
        Text("Exercise measure: ${result.exercise.measure}"),
        Text("Exercise target: ${result.exercise.target}"),
        Text("And you completed ${result.percent*100} percent of it",style: TextStyle(color: (result.percent>=1.0?Colors.green:Colors.blue)))
      ]
    );
  }
}

